template<typename T>
class AvlNode
{
    T element;
    AvlNode *pLeft;
    AvlNode *pRight;
    int deep;
    int count;
    AvlNode(const T & theElement, AvlNode *init_left, AvlNode *init_right, int init_deep = 0, int init_cnt = 0)
        : element(theElement), pLeft(init_left), pRight(init_right), deep(init_deep), count(init_cnt) {}
    
    template<typename ElementType>
    friend class AVLSet;
};

