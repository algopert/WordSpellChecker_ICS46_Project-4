// WordChecker.cpp
//
// ICS 46 Winter 2022
// Project #4: Set the Controls for the Heart of the Sun
//
// Replace and/or augment the implementations below as needed to meet
// the requirements.


#include "WordChecker.hpp"
#include <string>


WordChecker::WordChecker(const Set<std::string>& words)
    : words{words}
{
}


bool WordChecker::wordExists(const std::string& word) const
{
    return words.contains(word);
}


std::vector<std::string> WordChecker::findSuggestions(const std::string& word) const
{
    int i, j;
    std::string charStack = "QWERTYUIOPASDFGHJKLZXCVBNM";
    std::vector<std::string> mySuggestionWord;

    std::string tmpStr;

    
    for (i = 1; i < word.length(); i++) //SPILTING
    {
        tmpStr = word;

        std::string rgtTmpStr, lftTmpStr;
        rgtTmpStr = tmpStr.substr(0, i);
        lftTmpStr = tmpStr.substr(i);
        
        if (wordExists(rgtTmpStr) && wordExists(lftTmpStr) && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), rgtTmpStr) == mySuggestionWord.end() && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), lftTmpStr) == mySuggestionWord.end())
            mySuggestionWord.push_back(tmpStr.insert(i, " "));
    }
    


    for (i = 0; i < charStack.length(); i++) // INSERT CHAR
    {
        for (j = 0; j <= word.length(); j++)
        {
            tmpStr = word;
            tmpStr.insert(j, 1, charStack[i]);

            if (wordExists(tmpStr) && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), tmpStr) == mySuggestionWord.end())
                mySuggestionWord.push_back(tmpStr);
        }
    }

    for(i = 0; i < word.length() - 1; i++) // SWAPPING
    {
        tmpStr = word;
        std::swap(tmpStr[i], tmpStr[i+1]);
        if (wordExists(tmpStr) && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), tmpStr) == mySuggestionWord.end())
            mySuggestionWord.push_back(tmpStr);
    }

    for (i = 0; i < charStack.length(); i++) //REPLACING
    {
        for (j = 0; j < word.length(); j++)
        {
            tmpStr = word;
            tmpStr.replace(j, 1, 1, charStack[i]);

            if (wordExists(tmpStr) && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), tmpStr) == mySuggestionWord.end())
                mySuggestionWord.push_back(tmpStr);
        }
    }

    
    for (i = 0; i < word.length(); i++) //DELETING
    {
        tmpStr = word;
        tmpStr.erase(i, 1);

        if (wordExists(tmpStr) && std::find(mySuggestionWord.begin(), mySuggestionWord.end(), tmpStr) == mySuggestionWord.end())
            mySuggestionWord.push_back(tmpStr);
    }
    

    return mySuggestionWord;
}

