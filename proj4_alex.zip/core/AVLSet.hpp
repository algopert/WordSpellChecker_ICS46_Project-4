// AVLSet.hpp
//
// ICS 46 Winter 2022
// Project #4: Set the Controls for the Heart of the Sun
//
// An AVLSet is an implementation of a Set that is an AVL tree, which uses
// the algorithms we discussed in lecture to maintain bBalance every time a
// new element is added to the set.  The balancing is actually optional,
// with a bool parameter able to be passed to the constructor to explicitly
// turn the balancing on or off (on is default).  If the balancing is off,
// the AVL tree acts like a binary search tree (e.g., it will become
// degenerate if elements are added in ascending order).
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector) to store the information
// in your data structure.  Instead, you'll need to implement your AVL tree
// using your own dynamically-allocated nodes, with pointers connecting them,
// and with your own balancing algorithms used.

#ifndef AVLSET_HPP
#define AVLSET_HPP

#include <functional>
#include "Set.hpp"




template<typename T>
class AvlNode
{
    T element;
    AvlNode *pLeft;
    AvlNode *pRight;
    int deep;
    int count;
    AvlNode(const T & theElement, AvlNode *_lt, AvlNode *_rt, int lvl = 0, int cnt = 0)
        : element(theElement), pLeft(_lt), pRight(_rt), deep(lvl), count(cnt) {}
    
    template<typename ElementType>
    friend class AVLSet;
};

template <typename ElementType>
class AVLSet : public Set<ElementType>
{
public:
    // A VisitFunction is a function that takes a reference to a const
    // ElementType and returns no value.
    using VisitFunction = std::function<void(const ElementType&)>;

public:
    // Initializes an AVLSet to be empty, with or without balancing.
    explicit AVLSet(bool shouldBalance = true);

    // Cleans up the AVLSet so that it leaks no memory.
    ~AVLSet() noexcept override;

    // Initializes a new AVLSet to be a copy of an existing one.
    AVLSet(const AVLSet& s);

    // Initializes a new AVLSet whose contents are moved from an
    // expiring one.
    AVLSet(AVLSet&& s) noexcept;

    // Assigns an existing AVLSet into another.
    AVLSet& operator=(const AVLSet& s);

    // Assigns an expiring AVLSet into another.
    AVLSet& operator=(AVLSet&& s) noexcept;


    // isImplemented() should be modified to return true if you've
    // decided to implement an AVLSet, false otherwise.
    bool isImplemented() const noexcept override;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function always runs in O(log n) time
    // when there are n elements in the AVL tree.
    void add(const ElementType& element) override;


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function always runs in O(log n) time when
    // there are n elements in the AVL tree.
    bool contains(const ElementType& element) const override;


    // size() returns the number of elements in the set.
    unsigned int size() const noexcept override;


    // height() returns the height of the AVL tree.  Note that, by definition,
    // the height of an empty tree is -1.
    int height() const noexcept;


    // preorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a preorder traversal of the AVL
    // tree.
    void preorder(VisitFunction visit) const;


    // inorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by an inorder traversal of the AVL
    // tree.
    void inorder(VisitFunction visit) const;


    // postorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a postorder traversal of the AVL
    // tree.
    void postorder(VisitFunction visit) const;


private:
    // You'll no doubt want to add member variables and "helper" member
    // functions here.
    bool bBalance = true;
    int sizeOfTree;
    AvlNode<ElementType> *root;

    void makeEmpty(AvlNode<ElementType> * & t) const;
    AvlNode<ElementType> *clone(AvlNode<ElementType> *t) const;
    void add(const ElementType& element, AvlNode<ElementType> * & root);
    void addWord(const ElementType& element);
    void addWord(ElementType element, AvlNode<ElementType> *& root);
    int max(int a1, int a2) const;
    int deep(AvlNode<ElementType> *root);
    void balanceLeft(AvlNode<ElementType> * & k2);
    void balanceRight(AvlNode<ElementType> * & k1);
    void twiceToRightWord(AvlNode<ElementType> * & k3);
    void twiceToLeftWord(AvlNode<ElementType> * & k1);
    void preorderHelper(const AvlNode<ElementType> *& root, VisitFunction visit) const;
    void inorderHelper(const AvlNode<ElementType> *& root, VisitFunction visit) const;
    void postorderHelper(const AvlNode<ElementType> *&root, VisitFunction visit) const;
};


template <typename ElementType>
AVLSet<ElementType>::AVLSet(bool shouldBalance)
{
    this->root = NULL;
    sizeOfTree = 0;
    bBalance = shouldBalance;
}


template <typename ElementType>
AVLSet<ElementType>::~AVLSet() noexcept
{
    makeEmpty(this->root);
    sizeOfTree = 0;
}


template <typename ElementType>
AVLSet<ElementType>::AVLSet(const AVLSet& s)
{
    this->bBalance = s.bBalance;
    this->sizeOfTree = s.sizeOfTree;
    this->root = s.root;
}

template <typename ElementType>
void AVLSet<ElementType>::makeEmpty(AvlNode<ElementType> * & t) const
{
    if (t != NULL)
    {
        makeEmpty(t->pLeft);
        makeEmpty(t->pRight);
        delete t;
    }
    t = NULL;
}


template <typename ElementType>
AVLSet<ElementType>::AVLSet(AVLSet&& s) noexcept
{
    this->bBalance = std::move(s.bBalance);
    this->sizeOfTree = std::move(s.sizeOfTree);
    this->root = std::move(s.root);
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(const AVLSet& s)
{
    if (this != &s)
    {
        makeEmpty(root);
        root = clone(s.root);
    }
    return *this;
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(AVLSet&& s) noexcept
{
    if (this != &s)
    {
        makeEmpty(root);
        root = clone(s.root);
    }
    return *this;
}

template <typename ElementType>
AvlNode<ElementType> *AVLSet<ElementType>::clone(AvlNode<ElementType> *t) const
{
    if (t == NULL)
        return NULL;
    else
        return new AvlNode(t->element, clone(t->pLeft), clone(t->pRight), t->deep, t->count);
}




template <typename ElementType>
bool AVLSet<ElementType>::isImplemented() const noexcept
{
    return true; //-------------------------------------------------------
}


template <typename ElementType>
void AVLSet<ElementType>::add(const ElementType& element)
{
    if(contains(element))
    {
        addWord(element);
    }
    else
    {
        add(element, this->root);
        sizeOfTree++;
    }
}

template<typename ElementType>
void AVLSet<ElementType>::addWord(const ElementType & element)
{
    addWord(element, this->root);
}

template<typename ElementType>
void AVLSet<ElementType>::addWord(ElementType element, AvlNode<ElementType> *&root)
{
    if(element < root->element)
        addWord(element, root->pLeft);
    if(element > root->element)
        addWord(element, root->pRight);
    else
        root->count += 1;
}

template<typename ElementType>
void AVLSet<ElementType>::add(const ElementType& element, AvlNode<ElementType> * & root)
{
    if(root == NULL)
    {
        root = new AvlNode<ElementType>(element, NULL, NULL, 0, 0);
        root->count = 1;
    }
    else if (element < root->element)
    {
        add(element, root->pLeft);
        if(bBalance == true)
        {
            if((deep(root->pLeft) - deep(root->pRight)) == 2)
            {
                if(element < root->pLeft->element)
                    balanceLeft(root);
                else
                    twiceToRightWord(root);
            }
        }
    }
    else if(root->element < element)
    {
        add(element, root->pRight);
        if(bBalance == true)
        {
            if(deep(root->pRight) - deep(root->pLeft) == 2)
            {
                if(root->pRight->element < element)
                    balanceRight(root);
                else
                twiceToLeftWord(root);
            }
        }
    }

    if(root != NULL)
        root->deep = max(deep(root->pLeft), deep(root->pRight)) + 1;
}

template<typename ElementType>
int AVLSet<ElementType>::max(int a1, int a2) const
{
    return a1 > a2? a1 : a2;
}

template<typename ElementType>
int AVLSet<ElementType>::deep(AvlNode<ElementType> *root)
{
    return root == NULL ? -1: root->deep;
}

template<typename ElementType>
void AVLSet<ElementType>::balanceLeft(AvlNode<ElementType> * & k2)
{
    AvlNode<ElementType> *k1 = k2->pLeft;
    k2->pLeft = k1->pRight;
    k1->pRight = k2;
    k2->deep = max(deep(k2->pLeft), deep(k2->pRight)) + 1;
    k1->deep = max(deep(k1->pLeft), k2->deep) + 1;
    k2 = k1;
}

template<typename ElementType>
void AVLSet<ElementType>::balanceRight(AvlNode<ElementType> * & k1)
{
    AvlNode<ElementType> *k2 = k1->pRight;
    k1->pRight = k2->pLeft;
    k2->pLeft = k1;
    k1->deep = max(deep(k1->pLeft), deep(k1->pRight)) + 1;
    k2->deep = max(deep(k2->pRight), k1->deep) + 1;
    k1 = k2;
}

template<typename ElementType>
void AVLSet<ElementType>::twiceToRightWord(AvlNode<ElementType> * & k3)
{
    balanceRight(k3->pLeft);
    balanceLeft(k3);
}

template<typename ElementType>
void AVLSet<ElementType>::twiceToLeftWord(AvlNode<ElementType> * & k1)
{
    balanceLeft(k1->pRight);
    balanceRight(k1);
}


template <typename ElementType>
bool AVLSet<ElementType>::contains(const ElementType& element) const
{
    AvlNode<ElementType>* n = this->root;
    
    while(n != NULL)
    {
        if(element == n->element)
            return true;
        else if(element < n->element)
            n = n->pLeft;
        else if(element > n->element)
            n = n->pRight;
    }

    return false;
}


template <typename ElementType>
unsigned int AVLSet<ElementType>::size() const noexcept
{
    return this->sizeOfTree;
}


template <typename ElementType>
int AVLSet<ElementType>::height() const noexcept
{
    return this->root == NULL ? -1 : this->root->deep;
}


template <typename ElementType>
void AVLSet<ElementType>::preorder(VisitFunction visit) const
{
    const AvlNode<ElementType>* n = this->root;
    preorderHelper(n, visit);
}

template <typename ElementType>
void AVLSet<ElementType>::preorderHelper(const AvlNode<ElementType> *&root, VisitFunction visit) const
{
    if(root == NULL)
        return;
    const AvlNode<ElementType>*& n = root;
    const AvlNode<ElementType>* l = root->pLeft;
    const AvlNode<ElementType>* r = root->pRight;
    visit(n->element);
    preorderHelper(l, visit);
    preorderHelper(r, visit);
}

template <typename ElementType>
void AVLSet<ElementType>::inorder(VisitFunction visit) const
{
    const AvlNode<ElementType>* n = this->root;
    inorderHelper(n, visit);
}

template<typename ElementType>
void AVLSet<ElementType>::inorderHelper(const AvlNode<ElementType> *&root, VisitFunction visit) const
{
    if(root == NULL)
        return;
    const AvlNode<ElementType>*& n = root;
    const AvlNode<ElementType>* l = root->pLeft;
    const AvlNode<ElementType>* r = root->pRight;
    inorderHelper(l, visit);
    visit(n->element);
    inorderHelper(r, visit);
}

template <typename ElementType>
void AVLSet<ElementType>::postorder(VisitFunction visit) const
{
    const AvlNode<ElementType>* n = this->root;
    postorderHelper(n,visit);
}

template<typename ElementType>
void AVLSet<ElementType>::postorderHelper(const AvlNode<ElementType> *&root, VisitFunction visit) const
{
    if(root == NULL)
        return;
    const AvlNode<ElementType>*& n = root;
    const AvlNode<ElementType>* l = root->pLeft;
    const AvlNode<ElementType>* r = root->pRight;
    postorderHelper(l, visit);
    postorderHelper(r, visit);
    visit(n->element);
}

#endif

